#!/bin/bash

module load bakta/1.9.3--pyhdfd78af_0

for f in *_cps.fa
do
  bsub.py 50 bakta_${f} bakta $f -o ${f}_bakta --skip-plot
  sleep 1
done
